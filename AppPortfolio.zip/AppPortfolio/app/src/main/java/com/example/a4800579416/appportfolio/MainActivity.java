package com.example.a4800579416.appportfolio;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //get all the tab options and display it in a list.
        String[] tabs = {"Welcome", "About/Resume", "Coursework: Core", "Coursework: Emphasis", "Grades", "Contact", "Web version"};
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_main, R.id.tab, tabs));
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        //It will launch certain pages depending on what the user clicks
        switch (position)
        {
            case 0:
                startActivity(new Intent(MainActivity.this, Welcome.class));
                break;
            case 1:
                startActivity(new Intent(MainActivity.this, AboutandResume.class));
                break;
            case 2:
                startActivity(new Intent(MainActivity.this, Core.class));
                break;
            case 3:
                startActivity(new Intent(MainActivity.this, Emphasis.class));
                break;
            case 4:
                startActivity(new Intent(MainActivity.this, Grades.class));
                break;
            case 5:
                startActivity(new Intent(MainActivity.this, Contact.class));
                break;
            case 6:
                startActivity(new Intent(MainActivity.this, WebVersion.class));
                break;

        }
    }
}
