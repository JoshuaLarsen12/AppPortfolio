package com.example.a4800579416.appportfolio;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Core extends ListActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //List of the core classes the user can pick
        String[] coreClasses = {"Introduction to Information Technology", "Web Development Fundamentals", "Software Development Fundamentals", "Database Development Fundamentals", "Version Control Fundamentals", "Job Seeking Skills", "<-- Back"};
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_core, R.id.tab, coreClasses));

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {

        //All overview in order
        String[] overviews = {"In this course I learned a lot about technology, computer, security, software and hardware, the internet, etc." +
                " It talked about security and how you should always have good passwords and updates updated. And about data centers with severs that hold all the information in the “Cloud”." +
                " It also talked about computer hardware and what parts do what.", "In this course I learned HTML and CSS3. " +
                "I also when over some of the principles of design and what you should do to your website for certain target audiences.  " +
                "HTML and CSS are languages that browsers read to render a web page. " +
                "I also did a little bit of JavaScript but not much.", "In this class I learned Visual Basic, It gave an introduction to the basics of programming." +
                " for example I explained what data types are and how you can use them when building software." +
                " And it also showed me how to use Visual Studio, you can do many different kinds of projects with Visual Studio but in this class we just used windows forms to build to build projects.",
                "I learned in this class about databases and SQL. " +
                        "Databases are what most companies or business use to store data and be organized." +
                        " Databases are better and more efficient than storing all your documents and data in physical folders." +
                        " I also learned that databases need to be secure and safe from outsiders or hackers." +
                        " If you don’t have a secure database your data or other sensitive information can be taken.",
                "I learned git and some version control software." +
                        " Version control is keeping projects organized and having different versions of that project." +
                        " It also is for when many people are working on the same project and the all need to have access to the files and update it so they use version control/git to do that.",
                "In this class I learned how to build a resume and get started in looking for a job." +
                        " I did a mock interview and practiced interview questions." +
                        " I also learn where to look when you are looking for a job, you can go to a site like indeed and see tons of jobs or you can go to a certain company’s website and see if they are hiring for a certain position you want."};

        //All Reflections in order
        String[] reflections ={"It has given me an understanding on how the internet and computers work and how they are in our lives and what role they play in them." +
                " Technology is always changing and there is always something new to learn in IT." +
                " It was a good course and I wouldn’t know as much about IT if I haven’t taken the course.", "It is good that I took this course." +
                " It gave me an understanding of how websites work and how you can make a website." +
                " It let me know how to properly place things so your site can look good. If it doesn’t look good then it will not attract people to it and you always want more people to see your site." +
                " especially if it is your target audience.", "This class was great to get started with programming!" +
                " It showed what kinds of things you could build with programming. Some examples are a to-do list, store records, games, etc." +
                " Programming is an important in IT, it gives you more options and just a better understanding of technology and how computers work in general.", "This class taught me about databases." +
                " Databases are one of the most important parts of IT! A lot of information we need get or store are in databases." +
                " If I didn’t understand databases I would not know how to use database when the time comes." +
                " And in IT database are definitely used a lot!", "Version control is definitely used in IT a lot!" +
                " If we didn’t have git/version control then everything would just be a mess and nothing would be organized." +
                " Also you and your coworkers or whoever you’re working with would not be able to share project files or at least not very well." +
                " It would be chaos without git/version control.", "This class helped me gain the skills I need when looking for a job." +
                " I now know what kinds of questions to expect when I go in for an interview." +
                " I know how to target my resume to specific places and only list relevant skills." +
                " If I didn’t take this class I wouldn’t know how to get started when looking for a job once I finish school."};

        String overview = "";

        String reflection = "";
        //depending on what the user clicked it will save a overview and reflection
        switch (position)
        {
            case 0:
                overview = overviews[0];
                reflection = reflections[0];
                break;
            case 1:
                overview = overviews[1];
                reflection = reflections[1];
                break;
            case 2:
                overview = overviews[2];
                reflection = reflections[2];
                break;
            case 3:
                overview = overviews[3];
                reflection = reflections[3];
                break;
            case 4:
                overview = overviews[4];
                reflection = reflections[4];
                break;
            case 5:
                overview = overviews[5];
                reflection = reflections[5];
                break;
                //The last item in the list is a back button that will take the user back to the main activity.
            case 6:
                startActivity(new Intent(Core.this, MainActivity.class));
                break;
        }
        //As long as the user doesn't click the back button it will save those values so it can be passed to the CoreClass activity so it can display the overview and reflection for the user.
        if(position != 6)
        {
        final SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putString("overview", overview);
        editor.putString("reflection", reflection);
        editor.commit();
        startActivity(new Intent(Core.this, CoreClass.class));
        }
    }
}
