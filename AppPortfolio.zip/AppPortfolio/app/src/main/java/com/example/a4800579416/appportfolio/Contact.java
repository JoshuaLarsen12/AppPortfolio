package com.example.a4800579416.appportfolio;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class Contact extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        //Get the submit button
        Button btSubmitContact = findViewById(R.id.btnSubmitContact);
        //get the editText components
        final EditText etxtName = findViewById(R.id.etxtName);
        final EditText etxtComment = findViewById(R.id.etxtComment);
        final RadioGroup reason = findViewById(R.id.rgReasons);
        //get the back button
        Button btContactBack = findViewById(R.id.btnContactBack);

        //When the user clicks submit It will see what radio button the user clicked and determined the output.
        btSubmitContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int option = reason.getCheckedRadioButtonId();
                RadioButton rbClicked = findViewById(option);
                String contactReason = "";
                switch (rbClicked.getText().toString())
                {
                    case "Employer":
                        contactReason = "Employer";
                        break;
                    case "Networking":
                        contactReason = "Networking";
                        break;
                    case "Other":
                        contactReason = "Other";
                        break;

                }
                //When the submit button is clicked the user will be directed to an email client where the input they entered is automatcily put into the email, all they have to do then is push send. or if they are already not signed in they have to sign in.
                Intent email = new Intent(Intent.ACTION_SENDTO, Uri.fromParts("mailto", "Joshylarsen81@gmail.com", null));
                email.putExtra(Intent.EXTRA_SUBJECT, "Comment from user on app portfolio");
                email.putExtra(Intent.EXTRA_TEXT, "Reason for contact: "+ contactReason +"\n\nName: " + etxtName.getText().toString() + "\n\nComment: " +  etxtComment.getText().toString());

                try {
                    startActivity(Intent.createChooser(email, "Send mail..."));
                    finish();
                    Toast.makeText(Contact.this, "Opening default or email client of choice...", Toast.LENGTH_LONG).show();
                } catch (android.content.ActivityNotFoundException ex)
                {
                    Toast.makeText(Contact.this, "There is no email client installed.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //back button launches mainActivity
        btContactBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Contact.this, MainActivity.class));
            }
        });
    }
}
