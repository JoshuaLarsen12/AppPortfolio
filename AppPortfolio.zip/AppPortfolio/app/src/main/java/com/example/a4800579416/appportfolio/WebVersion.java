package com.example.a4800579416.appportfolio;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebVersion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Launch my website so the user can see the site version of the app.
        Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://eportfoliojoshualarsen.wordpress.com/"));
        startActivity(web);
    }
}
