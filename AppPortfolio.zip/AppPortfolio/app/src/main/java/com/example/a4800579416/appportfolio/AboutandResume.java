package com.example.a4800579416.appportfolio;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class AboutandResume extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutand_resume);
        //get button to see resume
        Button btResume = findViewById(R.id.btnResume);
        //Get the back button
        Button btAboutBack = findViewById(R.id.btnAboutBack);

        //when resume button is clicked it will redirect the user to my resume on my website
        btResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://eportfoliojoshualarsen.wordpress.com/resume/")));
            }
        });
        //When the back button is clicked it will redirect the user to the start main activity page
        btAboutBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AboutandResume.this, MainActivity.class));
            }
        });
    }
}
