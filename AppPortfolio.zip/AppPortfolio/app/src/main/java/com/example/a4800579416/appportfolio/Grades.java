package com.example.a4800579416.appportfolio;

import android.content.Intent;
import android.sax.StartElementListener;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Grades extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grades);
        //get the back button
        Button btGradesBack =  findViewById(R.id.btnGradesBack);
        //click the back button to run main activity
        btGradesBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Grades.this, MainActivity.class));
            }
        });
    }
}
