package com.example.a4800579416.appportfolio;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TabHost;
import android.widget.TextView;

public class EmphasisClass extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_core_class);
        //Get textviews, buttons, and Tabhost.
        TextView overview = findViewById(R.id.txtOverview1);
        TextView reflection = findViewById(R.id.txtReflection1);
        Button btCoreBack = findViewById(R.id.btnCoreBack);
        TabHost tabHost = findViewById(R.id.tabHost);
        tabHost.setup();

        //set up tab 1
        TabHost.TabSpec spec = tabHost.newTabSpec("Overview");
        spec.setContent(R.id.Overview);
        spec.setIndicator("Overview");
        tabHost.addTab(spec);

        //set up tab 2
        spec = tabHost.newTabSpec("Reflection");
        spec.setContent(R.id.Reflection);
        spec.setIndicator("Reflection");
        tabHost.addTab(spec);
        //Get the saved overview and reflection and display it to the user
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        String strOverview = sharedPref.getString("overview", "");
        String strReflection = sharedPref.getString("reflection", "");

        overview.setText(strOverview);
        reflection.setText(strReflection);

        //Back button launches the page that was before which is the emphasis page.
        btCoreBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EmphasisClass.this, Emphasis.class));
            }
        });

    }
}
