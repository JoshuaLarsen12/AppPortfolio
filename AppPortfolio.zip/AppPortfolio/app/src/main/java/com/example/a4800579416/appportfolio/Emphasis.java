package com.example.a4800579416.appportfolio;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Emphasis extends ListActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Set the classes that will display in a list
        String[] coreClasses = {"JAVA Programming I", "JAVA Programming II", "C# Programming I", "C# Programming II", "PHP and MySQL", "<-- Back"};
        setListAdapter(new ArrayAdapter<String>(this, R.layout.activity_core, R.id.tab, coreClasses));

    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {

        //save all the emphasis Overviews
        String[] overviews = {"In this class I learned Java, Java is a object oriented programming language." +
                " It is a programming language that is used a lot." +
                " I coded some programs and got myself familiar with the language.", "In this class I gain expanded my knowledge on Java." +
                " I coded some projects and read about new topics in Java." +
                " Some new topics I learned about was Recursion, Inheritance, Polymorphism, writing to a file, reading from a file, and some GUI stuff.", "In this class I coded a lot and learned more about C#." +
                " I learned more about the C# language and I also learned more about visual studio." +
                " I now know my way around visual studio more and I know more about what kinds of controls there are for windows forms.", "In this class I got to use C# with other kinds of software." +
                " I learned about how to use LINQ and databases with C#." +
                " I also learned about asp.net and how to use C# code to make a website." +
                " And with that website I learned about web services and how to use web services with the website.", "In this course I learned about using SQL (a relational database management system) with PHP and that is a server side programming language." +
                " In PHP you can run a SQL query to get data, edit data, add data, or remove data." +
                " PHP also gives you the ability to add things to a website like a login and signup page, you can make cookies or sessions, and you can perform calculations and store variables to return data like other client side programming languages."};

        //save all the emphasis reflections
        String[] reflections ={"This class gave me a lot better understanding of how object oriented programming works." +
                " Object oriented programming languages such as Java are very commonly used in this field. So this class is probably one of the most important ones out of all of them.", "I learned a lot more about the Java programming language." +
                " Java is used in this field a lot." +
                " I learned how to save things to a text file, and what good is an application or program if you can’t save your data? I also learned about Inheritance, Recursion, and Polymorphism and those are just things to help a programmer so they don’t have to type way more code than needed.", "This class was an important one to take." +
                " C# is a very common language that lots of people and business’s use." +
                " Also visual studio is used quite a bit in this industry too." +
                " This class helped me and prepared me more for this field.", "This class gave me a better understanding of C# and how it can be applied to other software." +
                " People and businesses use databases and websites quite often." +
                " So having these skill on using C# with those is very useful in this industry.", "This class helped me understand the purpose of PHP and how it is used. Databases and server side programming languages are use a lot in the software industry. Almost everything is online and stored in databases. This is a big part of software development and is a good skill to learn."};

        String overview = "";

        String reflection = "";
        //depending on what the user clicked it will save a overview and reflection
        switch (position)
        {
            case 0:
                overview = overviews[0];
                reflection = reflections[0];
                break;
            case 1:
                overview = overviews[1];
                reflection = reflections[1];
                break;
            case 2:
                overview = overviews[2];
                reflection = reflections[2];
                break;
            case 3:
                overview = overviews[3];
                reflection = reflections[3];
                break;
            case 4:
                overview = overviews[4];
                reflection = reflections[4];
                break;
            case 5:
                //The last item in the list is a back button that will take the user back to the main activity.
                startActivity(new Intent(Emphasis.this, MainActivity.class));
                break;
        }
        //As long as the user doesn't click the back button it will save those values so it can be passed to the CoreClass activity so it can display the overview and reflection for the user.
        if(position != 5)
        {
            final SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putString("overview", overview);
            editor.putString("reflection", reflection);
            editor.commit();
            startActivity(new Intent(Emphasis.this, EmphasisClass.class));
        }
    }
}
